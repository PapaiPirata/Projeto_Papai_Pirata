# 🤖 Papai Pirata Bot (v2 com OpenAI + ElevenLabs)

Automatize a criação e publicação de conteúdo diário para pais com base em mensagens motivacionais.

## Funcionalidades

- 🧠 Geração de mensagens com **OpenAI GPT-4**
- 🖼️ Criação de imagens (mock) e vídeos com **áudio narrado via ElevenLabs**
- 📱 Simulação de postagem em redes sociais (Instagram, YouTube, TikTok)
- 📧 Envio de resumo por e-mail (simulado)
- ⏱️ Agendamento automático com `schedule`

## Instalação

1. Clone o projeto e instale as dependências:
```bash
pip install -r requirements.txt
```

2. Configure sua `.env`:
```
OPENAI_API_KEY=your_openai_api_key
ELEVENLABS_API_KEY=your_elevenlabs_api_key
```

3. Execute:
```bash
python main.py
```

## Próximos passos

- Integração real com Instagram Business, YouTube e TikTok usando OAuth.
- Geração real de imagem com DALL·E (OpenAI) ou Stability AI.
- Publicação automática real em redes sociais.

---
Feito por **Papai Pirata** 🏴‍☠️