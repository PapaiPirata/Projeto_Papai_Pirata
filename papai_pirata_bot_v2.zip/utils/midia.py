import requests
import os
from dotenv import load_dotenv

load_dotenv()
ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY")

def gerar_imagem(mensagem):
    print(f"Gerando imagem com a mensagem: {mensagem}")
    return "https://link_da_imagem_simulada.png"

def gerar_video(mensagem):
    print("Gerando narração com ElevenLabs...")
    headers = {
        "xi-api-key": ELEVENLABS_API_KEY,
        "Content-Type": "application/json"
    }
    data = {
        "text": mensagem,
        "voice_settings": {
            "stability": 0.5,
            "similarity_boost": 0.75
        }
    }
    voice_id = "TxGEqnHWrfWFTfGW9XjX"  # exemplo de voz
    response = requests.post(
        f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
        headers=headers,
        json=data
    )
    audio_path = "output/audio.mp3"
    os.makedirs("output", exist_ok=True)
    with open(audio_path, "wb") as f:
        f.write(response.content)

    print(f"Áudio gerado e salvo em: {audio_path}")
    return audio_path