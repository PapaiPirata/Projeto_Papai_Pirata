def postar_em_redes_sociais(midia_url, mensagem, tipo):
    print(f"[Simulação] Postando no Instagram, YouTube e TikTok com {tipo}.")
    print(f"Mensagem: {mensagem}")
    print(f"Mídia: {midia_url}")