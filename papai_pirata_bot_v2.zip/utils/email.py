def enviar_email(mensagem, midia_url, tipo):
    print(f"[Simulação] Enviando e-mail com {tipo} do dia.")
    print(f"Mensagem: {mensagem}")
    print(f"Mídia: {midia_url}")