import openai
import os
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

def gerar_mensagem_motivacional(data_formatada):
    prompt = f"Hoje é {data_formatada}. Crie uma mensagem motivacional divertida e criativa para pais com tom de pirata e humor leve."
    resposta = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return resposta.choices[0].message.content.strip()