import schedule
import time

def agendar_execucao(funcao):
    schedule.every().day.at("08:00").do(funcao)
    print("Agendado para rodar diariamente às 08:00")
    while True:
        schedule.run_pending()
        time.sleep(60)