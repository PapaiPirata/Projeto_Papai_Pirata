from utils.tiktok_upload import upload_video_tiktok
import os

def postar_em_redes_sociais(midia_path, mensagem, tipo):
    print(f"[Simulação] Postando no TikTok com {tipo}...")

    if tipo == "vídeo":
        access_token = os.getenv("TIKTOK_ACCESS_TOKEN")
        if not access_token:
            print("⚠️ TIKTOK_ACCESS_TOKEN não definido.")
            return
        resposta = upload_video_tiktok(midia_path, access_token)
        print("Resposta TikTok:", resposta)
    else:
        print(f"Imagem postada (simulada): {midia_path}")