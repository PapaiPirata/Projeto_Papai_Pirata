import requests

def upload_video_tiktok(video_path, access_token):
    upload_url = "https://open.tiktokapis.com/v2/post/publish/"
    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    files = {
        "video": open(video_path, "rb")
    }
    data = {
        "title": "Mensagem do dia do Papai Pirata! 🏴‍☠️"
    }
    resp = requests.post(upload_url, headers=headers, files=files, data=data)
    return resp.json()