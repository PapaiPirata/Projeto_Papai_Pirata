import os
import requests
from urllib.parse import urlencode
from flask import Flask, request

CLIENT_KEY = os.getenv("TIKTOK_CLIENT_KEY")
CLIENT_SECRET = os.getenv("TIKTOK_CLIENT_SECRET")
REDIRECT_URI = os.getenv("TIKTOK_REDIRECT_URI")

AUTH_URL = "https://www.tiktok.com/v2/auth/authorize/"
TOKEN_URL = "https://open.tiktokapis.com/v2/oauth/token/"

SCOPES = ["user.info.basic", "video.upload"]

app = Flask(__name__)

@app.route("/")
def login():
    params = {
        "client_key": CLIENT_KEY,
        "scope": ",".join(SCOPES),
        "response_type": "code",
        "redirect_uri": REDIRECT_URI,
    }
    return f"<a href='{AUTH_URL}?{urlencode(params)}'>Conectar TikTok</a>"

@app.route("/callback")
def callback():
    code = request.args.get("code")
    data = {
        "client_key": CLIENT_KEY,
        "client_secret": CLIENT_SECRET,
        "code": code,
        "grant_type": "authorization_code",
        "redirect_uri": REDIRECT_URI,
    }
    resp = requests.post(TOKEN_URL, json=data)
    return resp.json()

if __name__ == "__main__":
    app.run(port=8080)