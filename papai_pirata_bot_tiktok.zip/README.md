# 🤖 Papai Pirata Bot (TikTok Integrado)

Bot automatizado para gerar conteúdo diário com OpenAI e ElevenLabs e postar no TikTok.

## Funcionalidades

- Gera mensagens motivacionais cômicas (GPT-4)
- Cria vídeos com narração (ElevenLabs)
- Alterna entre imagens e vídeos conforme o dia
- Integração real com TikTok (via OAuth)

## Instalação

```bash
pip install -r requirements.txt
```

## Variáveis de ambiente (.env)

```
OPENAI_API_KEY=xxx
ELEVENLABS_API_KEY=xxx
TIKTOK_CLIENT_KEY=xxx
TIKTOK_CLIENT_SECRET=xxx
TIKTOK_REDIRECT_URI=http://localhost:8080/callback
TIKTOK_ACCESS_TOKEN=token_gerado_após_oauth
```

## Autenticação TikTok

```bash
python utils/tiktok_auth.py
```

Acesse: http://localhost:8080/

Copie o `access_token` e cole no `.env`.

## Execução

```bash
python main.py
```

---
Feito por **Papai Pirata** 🏴‍☠️