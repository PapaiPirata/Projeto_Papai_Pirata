import datetime
from utils.ia import gerar_mensagem_motivacional
from utils.midia import gerar_imagem, gerar_video
from utils.rede_social import postar_em_redes_sociais
from utils.scheduler import agendar_execucao

def rotina_diaria():
    hoje = datetime.datetime.now()
    dia = hoje.day
    data_formatada = hoje.strftime("%d/%m/%Y, %A")

    print(f"Executando rotina do dia {data_formatada}...")

    mensagem = gerar_mensagem_motivacional(data_formatada)

    if dia % 2 == 0:
        midia_path, tipo = gerar_imagem(mensagem), "imagem"
    else:
        midia_path, tipo = gerar_video(mensagem), "vídeo"

    postar_em_redes_sociais(midia_path, mensagem, tipo)

if __name__ == "__main__":
    agendar_execucao(rotina_diaria)