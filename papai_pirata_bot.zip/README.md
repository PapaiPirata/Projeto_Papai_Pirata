# 🤖 Papai Pirata Bot

Este projeto automatiza a criação e publicação de posts diários com base em mensagens motivacionais para pais, alternando entre **imagem (dias pares)** e **vídeo (dias ímpares)**.

## Funcionalidades

- 📅 **Agendamento diário** (08:00)
- 🤖 **Geração de mensagens** com IA (pode usar Gemini ou OpenAI)
- 🎨 **Criação de imagens e vídeos** com base na mensagem
- 📱 **Publicação automática** no Instagram, TikTok e YouTube
- 📧 **Envio de resumo por e-mail**

## Estrutura

- `main.py`: gerencia o fluxo principal
- `utils/ia.py`: gera a mensagem motivacional
- `utils/midia.py`: cria imagem ou vídeo
- `utils/rede_social.py`: publica nas redes
- `utils/email.py`: envia notificações
- `utils/scheduler.py`: agendamento com `schedule`

## Como usar

1. Instale as dependências:
```bash
pip install schedule
```

2. Execute o bot:
```bash
python main.py
```

## Futuro

- Integração real com Gemini API
- Geração de vídeo com narração usando ElevenLabs ou Pika Labs
- Upload real com autenticação via OAuth

---

Feito com ❤️ por Papai Pirata.