def postar_em_redes_sociais(midia_url, mensagem, tipo):
    print(f"Postando no Instagram, YouTube e TikTok com o {tipo} gerado.")
    print(f"Mensagem: {mensagem}")
    print(f"Mídia: {midia_url}")