def gerar_imagem(mensagem):
    # Simula a criação de imagem com base na mensagem
    print(f"Gerando imagem com a mensagem: {mensagem}")
    return "https://link_da_imagem_gerada.png"

def gerar_video(mensagem):
    # Simula a criação de vídeo com base na mensagem
    print(f"Gerando vídeo com a mensagem: {mensagem}")
    return "https://link_do_video_gerado.mp4"