from datetime import datetime

def gerar_mensagem_motivacional(data_formatada):
    # Aqui você pode integrar o Google Gemini ou OpenAI
    return f"Hoje é {data_formatada}. Mais um dia para enfrentar os mares da paternidade com coragem, bom humor e um tapa-olho de determinação!"